// @ts-nocheck
import prisma from '$lib/prisma';
/** @param {Parameters<import('./$types').PageServerLoad>[0]} event */
export async function load({ params }) {
    const blog = await prisma.blogPost.findUnique({
        where: {
            id: params.id
        },
        include: {
            contentBlocks: true
        }
    });
    return { blog };
};