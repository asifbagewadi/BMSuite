// @ts-nocheck
import prisma from '$lib/prisma';
/** */
export async function load() {
    const contacts = await prisma.contactSubmission.findMany();
    return { contacts };
};