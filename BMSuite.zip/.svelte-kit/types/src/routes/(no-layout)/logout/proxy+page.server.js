// @ts-nocheck
import { redirect } from '@sveltejs/kit';
import prisma from '$lib/prisma';

/** @param {Parameters<import('./$types').PageServerLoad>[0]} event */
export async function load({ locals, cookies }) {
  const sessionId = cookies.get('session');

  // 🔴 Clear session in DB
  if (sessionId) {
    await prisma.user.updateMany({
      where: { session_id: sessionId },
      data: { session_id: null }
    });
  }

  // 🔴 Clear cookies
  cookies.delete('session', { path: '/' });
  cookies.delete('org', { path: '/' });

  throw redirect(303, '/login');
}