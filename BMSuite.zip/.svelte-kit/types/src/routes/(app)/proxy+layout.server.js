// @ts-nocheck
import { redirect } from '@sveltejs/kit';

export async function load({ locals }) {
  if (!locals.user) {
    throw redirect(302, '/login');
  }

  return {
    user: locals.user
  };
}

/** @param {Parameters<import('./$types').LayoutServerLoad>[0]} event */
export async function load({locals}) {
    // console.log("locals", locals.user);
    return {
        user: locals.user,
        org_name: locals.org_name || 'BottleCRM'
    };
}

export const ssr = false;
