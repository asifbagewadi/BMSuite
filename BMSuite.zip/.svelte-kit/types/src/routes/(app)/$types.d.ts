import type * as Kit from '@sveltejs/kit';

type Expand<T> = T extends infer O ? { [K in keyof O]: O[K] } : never;
type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;
type RouteParams = {  };
type RouteId = '/(app)';
type MaybeWithVoid<T> = {} extends T ? T | void : T;
export type RequiredKeys<T> = { [K in keyof T]-?: {} extends { [P in K]: T[K] } ? never : K; }[keyof T];
type OutputDataShape<T> = MaybeWithVoid<Omit<App.PageData, RequiredKeys<T>> & Partial<Pick<App.PageData, keyof T & keyof App.PageData>> & Record<string, any>>
type EnsureDefined<T> = T extends null | undefined ? {} : T;
type OptionalUnion<U extends Record<string, any>, A extends keyof U = U extends U ? keyof U : never> = U extends unknown ? { [P in Exclude<A, keyof U>]?: never } & U : never;
export type Snapshot<T = any> = Kit.Snapshot<T>;
type LayoutRouteId = RouteId | "/(app)/app" | "/(app)/app/accounts" | "/(app)/app/accounts/new" | "/(app)/app/accounts/[accountId]" | "/(app)/app/accounts/[accountId]/edit" | "/(app)/app/cases" | "/(app)/app/cases/new" | "/(app)/app/cases/[caseId]" | "/(app)/app/cases/[caseId]/edit" | "/(app)/app/contacts" | "/(app)/app/contacts/new" | "/(app)/app/contacts/[contactId]" | "/(app)/app/contacts/[contactId]/edit" | "/(app)/app/invoices" | "/(app)/app/invoices/new" | "/(app)/app/invoices/[invoiceId]" | "/(app)/app/invoices/[invoiceId]/edit" | "/(app)/app/leads/new" | "/(app)/app/leads/open" | "/(app)/app/leads/[lead_id]" | "/(app)/app/leads/[lead_id]/edit" | "/(app)/app/opportunities" | "/(app)/app/opportunities/new" | "/(app)/app/opportunities/[opportunityId]" | "/(app)/app/opportunities/[opportunityId]/close" | "/(app)/app/opportunities/[opportunityId]/delete" | "/(app)/app/opportunities/[opportunityId]/edit" | "/(app)/app/profile" | "/(app)/app/support" | "/(app)/app/tasks" | "/(app)/app/tasks/calendar" | "/(app)/app/tasks/list" | "/(app)/app/tasks/new" | "/(app)/app/tasks/[task_id]" | "/(app)/app/tasks/[task_id]/edit" | "/(app)/app/users"
type LayoutParams = RouteParams & { accountId?: string; caseId?: string; contactId?: string; invoiceId?: string; lead_id?: string; opportunityId?: string; task_id?: string }
type LayoutServerParentData = EnsureDefined<import('../$types.js').LayoutServerData>;
type LayoutParentData = EnsureDefined<import('../$types.js').LayoutData>;

export type LayoutServerLoad<OutputData extends OutputDataShape<LayoutServerParentData> = OutputDataShape<LayoutServerParentData>> = Kit.ServerLoad<LayoutParams, LayoutServerParentData, OutputData, LayoutRouteId>;
export type LayoutServerLoadEvent = Parameters<LayoutServerLoad>[0];
export type LayoutServerData = Expand<OptionalUnion<EnsureDefined<Kit.LoadProperties<Awaited<ReturnType<typeof import('./proxy+layout.server.js').load>>>>>>;
export type LayoutData = Expand<Omit<LayoutParentData, keyof LayoutServerData> & EnsureDefined<LayoutServerData>>;
export type LayoutProps = { params: LayoutParams; data: LayoutData; children: import("svelte").Snippet }
export type RequestEvent = Kit.RequestEvent<RouteParams, RouteId>;