import type * as Kit from '@sveltejs/kit';

type Expand<T> = T extends infer O ? { [K in keyof O]: O[K] } : never;
type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;
type RouteParams = {  };
type RouteId = '/';
type MaybeWithVoid<T> = {} extends T ? T | void : T;
export type RequiredKeys<T> = { [K in keyof T]-?: {} extends { [P in K]: T[K] } ? never : K; }[keyof T];
type OutputDataShape<T> = MaybeWithVoid<Omit<App.PageData, RequiredKeys<T>> & Partial<Pick<App.PageData, keyof T & keyof App.PageData>> & Record<string, any>>
type EnsureDefined<T> = T extends null | undefined ? {} : T;
type OptionalUnion<U extends Record<string, any>, A extends keyof U = U extends U ? keyof U : never> = U extends unknown ? { [P in Exclude<A, keyof U>]?: never } & U : never;
export type Snapshot<T = any> = Kit.Snapshot<T>;
type LayoutRouteId = RouteId | "/(admin)/admin" | "/(admin)/admin/blogs" | "/(admin)/admin/blogs/new" | "/(admin)/admin/blogs/[id]" | "/(admin)/admin/blogs/[id]/edit" | "/(admin)/admin/contacts" | "/(admin)/admin/newsletter" | "/(app)/app" | "/(app)/app/accounts" | "/(app)/app/accounts/new" | "/(app)/app/accounts/[accountId]" | "/(app)/app/accounts/[accountId]/edit" | "/(app)/app/cases" | "/(app)/app/cases/new" | "/(app)/app/cases/[caseId]" | "/(app)/app/cases/[caseId]/edit" | "/(app)/app/contacts" | "/(app)/app/contacts/new" | "/(app)/app/contacts/[contactId]" | "/(app)/app/contacts/[contactId]/edit" | "/(app)/app/invoices" | "/(app)/app/invoices/new" | "/(app)/app/invoices/[invoiceId]" | "/(app)/app/invoices/[invoiceId]/edit" | "/(app)/app/leads/new" | "/(app)/app/leads/open" | "/(app)/app/leads/[lead_id]" | "/(app)/app/leads/[lead_id]/edit" | "/(app)/app/opportunities" | "/(app)/app/opportunities/new" | "/(app)/app/opportunities/[opportunityId]" | "/(app)/app/opportunities/[opportunityId]/close" | "/(app)/app/opportunities/[opportunityId]/delete" | "/(app)/app/opportunities/[opportunityId]/edit" | "/(app)/app/profile" | "/(app)/app/support" | "/(app)/app/tasks" | "/(app)/app/tasks/calendar" | "/(app)/app/tasks/list" | "/(app)/app/tasks/new" | "/(app)/app/tasks/[task_id]" | "/(app)/app/tasks/[task_id]/edit" | "/(app)/app/users" | "/(no-layout)/bounce" | "/(no-layout)/login" | "/(no-layout)/logout" | "/(no-layout)/org" | "/(no-layout)/org/new" | "/(site)" | "/(site)/blog" | "/(site)/blog/[slug]" | "/(site)/contact" | "/(site)/customization" | "/(site)/faq" | "/(site)/features" | "/(site)/features/account-management" | "/(site)/features/contact-management" | "/(site)/features/lead-management" | "/(site)/features/sales-pipeline" | "/(site)/migration" | "/(site)/pricing" | "/(site)/privacy-policy" | "/(site)/terms-of-service" | "/(site)/unsubscribe" | null
type LayoutParams = RouteParams & { id?: string; accountId?: string; caseId?: string; contactId?: string; invoiceId?: string; lead_id?: string; opportunityId?: string; task_id?: string; slug?: string }
type LayoutParentData = EnsureDefined<{}>;

export type LayoutServerData = null;
export type LayoutData = Expand<LayoutParentData>;
export type LayoutProps = { params: LayoutParams; data: LayoutData; children: import("svelte").Snippet }