
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/(site)" | "/(no-layout)" | "/(app)" | "/(admin)" | "/" | "/(admin)/admin" | "/(admin)/admin/blogs" | "/(admin)/admin/blogs/new" | "/(admin)/admin/blogs/[id]" | "/(admin)/admin/blogs/[id]/edit" | "/(admin)/admin/contacts" | "/(admin)/admin/newsletter" | "/(app)/app" | "/(app)/app/accounts" | "/(app)/app/accounts/new" | "/(app)/app/accounts/[accountId]" | "/(app)/app/accounts/[accountId]/edit" | "/(app)/app/cases" | "/(app)/app/cases/new" | "/(app)/app/cases/[caseId]" | "/(app)/app/cases/[caseId]/edit" | "/(app)/app/contacts" | "/(app)/app/contacts/new" | "/(app)/app/contacts/[contactId]" | "/(app)/app/contacts/[contactId]/edit" | "/(app)/app/invoices" | "/(app)/app/invoices/new" | "/(app)/app/invoices/[invoiceId]" | "/(app)/app/invoices/[invoiceId]/edit" | "/(app)/app/leads" | "/(app)/app/leads/new" | "/(app)/app/leads/open" | "/(app)/app/leads/[lead_id]" | "/(app)/app/leads/[lead_id]/edit" | "/(app)/app/opportunities" | "/(app)/app/opportunities/new" | "/(app)/app/opportunities/[opportunityId]" | "/(app)/app/opportunities/[opportunityId]/close" | "/(app)/app/opportunities/[opportunityId]/delete" | "/(app)/app/opportunities/[opportunityId]/edit" | "/(app)/app/profile" | "/(app)/app/support" | "/(app)/app/tasks" | "/(app)/app/tasks/calendar" | "/(app)/app/tasks/list" | "/(app)/app/tasks/new" | "/(app)/app/tasks/[task_id]" | "/(app)/app/tasks/[task_id]/edit" | "/(app)/app/users" | "/(site)/blog" | "/(site)/blog/[slug]" | "/(no-layout)/bounce" | "/(site)/contact" | "/(site)/customization" | "/(site)/faq" | "/(site)/features" | "/(site)/features/account-management" | "/(site)/features/contact-management" | "/(site)/features/lead-management" | "/(site)/features/sales-pipeline" | "/(no-layout)/login" | "/(no-layout)/logout" | "/(site)/migration" | "/(no-layout)/org" | "/(no-layout)/org/new" | "/(site)/pricing" | "/(site)/privacy-policy" | "/sitemap.xml" | "/(site)/terms-of-service" | "/(site)/unsubscribe";
		RouteParams(): {
			"/(admin)/admin/blogs/[id]": { id: string };
			"/(admin)/admin/blogs/[id]/edit": { id: string };
			"/(app)/app/accounts/[accountId]": { accountId: string };
			"/(app)/app/accounts/[accountId]/edit": { accountId: string };
			"/(app)/app/cases/[caseId]": { caseId: string };
			"/(app)/app/cases/[caseId]/edit": { caseId: string };
			"/(app)/app/contacts/[contactId]": { contactId: string };
			"/(app)/app/contacts/[contactId]/edit": { contactId: string };
			"/(app)/app/invoices/[invoiceId]": { invoiceId: string };
			"/(app)/app/invoices/[invoiceId]/edit": { invoiceId: string };
			"/(app)/app/leads/[lead_id]": { lead_id: string };
			"/(app)/app/leads/[lead_id]/edit": { lead_id: string };
			"/(app)/app/opportunities/[opportunityId]": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/close": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/delete": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/edit": { opportunityId: string };
			"/(app)/app/tasks/[task_id]": { task_id: string };
			"/(app)/app/tasks/[task_id]/edit": { task_id: string };
			"/(site)/blog/[slug]": { slug: string }
		};
		LayoutParams(): {
			"/(site)": { slug?: string };
			"/(no-layout)": Record<string, never>;
			"/(app)": { accountId?: string; caseId?: string; contactId?: string; invoiceId?: string; lead_id?: string; opportunityId?: string; task_id?: string };
			"/(admin)": { id?: string };
			"/": { id?: string; accountId?: string; caseId?: string; contactId?: string; invoiceId?: string; lead_id?: string; opportunityId?: string; task_id?: string; slug?: string };
			"/(admin)/admin": { id?: string };
			"/(admin)/admin/blogs": { id?: string };
			"/(admin)/admin/blogs/new": Record<string, never>;
			"/(admin)/admin/blogs/[id]": { id: string };
			"/(admin)/admin/blogs/[id]/edit": { id: string };
			"/(admin)/admin/contacts": Record<string, never>;
			"/(admin)/admin/newsletter": Record<string, never>;
			"/(app)/app": { accountId?: string; caseId?: string; contactId?: string; invoiceId?: string; lead_id?: string; opportunityId?: string; task_id?: string };
			"/(app)/app/accounts": { accountId?: string };
			"/(app)/app/accounts/new": Record<string, never>;
			"/(app)/app/accounts/[accountId]": { accountId: string };
			"/(app)/app/accounts/[accountId]/edit": { accountId: string };
			"/(app)/app/cases": { caseId?: string };
			"/(app)/app/cases/new": Record<string, never>;
			"/(app)/app/cases/[caseId]": { caseId: string };
			"/(app)/app/cases/[caseId]/edit": { caseId: string };
			"/(app)/app/contacts": { contactId?: string };
			"/(app)/app/contacts/new": Record<string, never>;
			"/(app)/app/contacts/[contactId]": { contactId: string };
			"/(app)/app/contacts/[contactId]/edit": { contactId: string };
			"/(app)/app/invoices": { invoiceId?: string };
			"/(app)/app/invoices/new": Record<string, never>;
			"/(app)/app/invoices/[invoiceId]": { invoiceId: string };
			"/(app)/app/invoices/[invoiceId]/edit": { invoiceId: string };
			"/(app)/app/leads": { lead_id?: string };
			"/(app)/app/leads/new": Record<string, never>;
			"/(app)/app/leads/open": Record<string, never>;
			"/(app)/app/leads/[lead_id]": { lead_id: string };
			"/(app)/app/leads/[lead_id]/edit": { lead_id: string };
			"/(app)/app/opportunities": { opportunityId?: string };
			"/(app)/app/opportunities/new": Record<string, never>;
			"/(app)/app/opportunities/[opportunityId]": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/close": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/delete": { opportunityId: string };
			"/(app)/app/opportunities/[opportunityId]/edit": { opportunityId: string };
			"/(app)/app/profile": Record<string, never>;
			"/(app)/app/support": Record<string, never>;
			"/(app)/app/tasks": { task_id?: string };
			"/(app)/app/tasks/calendar": Record<string, never>;
			"/(app)/app/tasks/list": Record<string, never>;
			"/(app)/app/tasks/new": Record<string, never>;
			"/(app)/app/tasks/[task_id]": { task_id: string };
			"/(app)/app/tasks/[task_id]/edit": { task_id: string };
			"/(app)/app/users": Record<string, never>;
			"/(site)/blog": { slug?: string };
			"/(site)/blog/[slug]": { slug: string };
			"/(no-layout)/bounce": Record<string, never>;
			"/(site)/contact": Record<string, never>;
			"/(site)/customization": Record<string, never>;
			"/(site)/faq": Record<string, never>;
			"/(site)/features": Record<string, never>;
			"/(site)/features/account-management": Record<string, never>;
			"/(site)/features/contact-management": Record<string, never>;
			"/(site)/features/lead-management": Record<string, never>;
			"/(site)/features/sales-pipeline": Record<string, never>;
			"/(no-layout)/login": Record<string, never>;
			"/(no-layout)/logout": Record<string, never>;
			"/(site)/migration": Record<string, never>;
			"/(no-layout)/org": Record<string, never>;
			"/(no-layout)/org/new": Record<string, never>;
			"/(site)/pricing": Record<string, never>;
			"/(site)/privacy-policy": Record<string, never>;
			"/sitemap.xml": Record<string, never>;
			"/(site)/terms-of-service": Record<string, never>;
			"/(site)/unsubscribe": Record<string, never>
		};
		Pathname(): "/" | "/admin" | "/admin/blogs" | "/admin/blogs/new" | `/admin/blogs/${string}` & {} | `/admin/blogs/${string}/edit` & {} | "/admin/contacts" | "/admin/newsletter" | "/app" | "/app/accounts" | "/app/accounts/new" | `/app/accounts/${string}` & {} | `/app/accounts/${string}/edit` & {} | "/app/cases" | "/app/cases/new" | `/app/cases/${string}` & {} | `/app/cases/${string}/edit` & {} | "/app/contacts" | "/app/contacts/new" | `/app/contacts/${string}` & {} | `/app/contacts/${string}/edit` & {} | "/app/invoices" | "/app/invoices/new" | `/app/invoices/${string}` & {} | `/app/invoices/${string}/edit` & {} | "/app/leads/new" | "/app/leads/open" | `/app/leads/${string}` & {} | `/app/leads/${string}/edit` & {} | "/app/opportunities" | "/app/opportunities/new" | `/app/opportunities/${string}` & {} | `/app/opportunities/${string}/close` & {} | `/app/opportunities/${string}/delete` & {} | `/app/opportunities/${string}/edit` & {} | "/app/profile" | "/app/support" | "/app/tasks" | "/app/tasks/calendar" | "/app/tasks/list" | "/app/tasks/new" | `/app/tasks/${string}` & {} | `/app/tasks/${string}/edit` & {} | "/app/users" | "/blog" | `/blog/${string}` & {} | "/bounce" | "/contact" | "/customization" | "/faq" | "/features" | "/features/account-management" | "/features/contact-management" | "/features/lead-management" | "/features/sales-pipeline" | "/login" | "/logout" | "/migration" | "/org" | "/org/new" | "/pricing" | "/privacy-policy" | "/sitemap.xml" | "/terms-of-service" | "/unsubscribe";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/funding.json" | "/logo.png" | "/logo_original.png" | string & {};
	}
}